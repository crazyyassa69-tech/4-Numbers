# 4 Numbers Android App

A native Android wrapper around the completed 4 Numbers game UI.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build App Bundle(s) / APK(s) > Build APK(s).

The generated APK will be in:
app/build/outputs/apk/debug/app-debug.apk
