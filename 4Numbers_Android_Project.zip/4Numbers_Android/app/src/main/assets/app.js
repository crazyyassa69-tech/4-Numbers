const $=id=>document.getElementById(id);
let state={p1:"Player 1",p2:"Player 2",secrets:{},turn:0,guess:[],rows:[],phase:"setup"};

function unique4(s){return s.length===4&&new Set(s).size===4&&[...s].every(x=>"123456789".includes(x))}
function show(id,on=true){$(id).hidden=!on}
function makePad(id,arr){const p=$(id);p.innerHTML="";for(let n=1;n<=9;n++){const b=document.createElement("button");b.className="key";b.textContent=n;b.onclick=()=>addDigit(n);p.appendChild(b)}}
function renderSlots(id,arr){const el=$(id);el.innerHTML="";for(let i=0;i<4;i++){const s=document.createElement("div");s.className="slot"+(i===arr.length?" active":"");s.textContent=arr[i]||"—";el.appendChild(s)}}
function addDigit(n){if(state.guess.length>=4||state.guess.includes(String(n)))return;state.guess.push(String(n));renderSlots("guessSlots",state.guess);$("submitGuess").disabled=!unique4(state.guess.join(""))}
function clearGuess(){state.guess=[];renderSlots("guessSlots",[]);$("submitGuess").disabled=true}
function setupSecret(playerIndex){
 state.phase="secret"; state.guess=[];
 show("setup",false);show("game",false);show("secret",true);
 const name=playerIndex===0?state.p1:state.p2;
 $("secretTitle").textContent=`${name}: Choose your secret number`;
 renderSlots("secretSlots",[]);
 makePad("secretPad",null);
 $("secretDone").disabled=true;
 $("secretDone").onclick=()=>{if(!unique4(state.guess.join("")))return;state.secrets[playerIndex]=state.guess.join("");state.guess=[];if(playerIndex===0)setupSecret(1);else startGame()};
 // replace pad handlers for secret entry
 [...$("secretPad").children].forEach(b=>b.onclick=()=>{if(state.guess.length<4&&!state.guess.includes(b.textContent)){state.guess.push(b.textContent);renderSlots("secretSlots",state.guess);$("secretDone").disabled=!unique4(state.guess.join(""))}});
}
function startGame(){
 state.phase="game";state.turn=0;state.rows=[];clearGuess();show("secret",false);show("game",true);
 $("nameA").textContent=state.p1;$("nameB").textContent=state.p2;updateTurn();renderRows();
}
function updateTurn(){const name=state.turn===0?state.p1:state.p2;$("turnTitle").textContent=`${name}'s turn`;clearGuess()}
function evaluate(secret,guess){let number=0,order=0;for(let i=0;i<4;i++){if(secret.includes(guess[i]))number++;if(secret[i]===guess[i])order++}return{number,order}}
function renderRows(){const r=$("rows");r.innerHTML="";state.rows.forEach(x=>{const d=document.createElement("div");d.className="row"+(x.order===4?" win":"");d.innerHTML=`<span>${x.name}</span><b>${x.guess}</b><span>${x.number}</span><span>${x.order}</span>`;r.appendChild(d)})}
$("submitGuess").onclick=()=>{
 const guess=state.guess.join(""),op=state.turn===0?1:0;
 const result=evaluate(state.secrets[op],guess);
 state.rows.push({name:state.turn===0?state.p1:state.p2,guess,...result});
 renderRows();
 if(result.number===4&&result.order===4){$("winner").innerHTML=`<div class="trophy">🏆</div><h2>🎉 ${state.turn===0?state.p1:state.p2} Wins!</h2><div>Number <b>4</b> &nbsp;|&nbsp; Order <b>4</b></div><button class="primary" onclick="location.reload()">Play Again</button>`;show("winner",true);$("turnCard").style.display="none";return}
 state.turn=op;updateTurn();
};
$("startBtn").onclick=()=>{state.p1=$("p1Name").value.trim()||"Player 1";state.p2=$("p2Name").value.trim()||"Player 2";setupSecret(0)}
$("resetBtn").onclick=()=>location.reload();
$("backBtn").onclick=()=>location.reload();
show("setup",true);show("secret",false);show("game",false);show("winner",false);
