4 NUMBERS — GUESS THE NUMBER
============================

This is a mobile-friendly 2-player game prototype.

Rules:
- Each player secretly chooses 4 different digits from 1–9.
- Players take turns guessing the opponent's 4-digit number.
- Number = how many guessed digits exist in the secret number.
- Order = how many guessed digits are also in the correct position.
- The first player to get Number 4 and Order 4 wins.

How to use:
1. Open index.html in a modern phone browser.
2. Enter both player names.
3. Player 1 enters a secret number and passes the phone.
4. Player 2 enters a secret number and passes the phone.
5. Take turns guessing.

The design uses a dark blue mathematical background and a responsive mobile UI.
